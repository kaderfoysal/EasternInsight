'use client';

import { useEffect, useState } from 'react';
import Image from 'next/image';

interface Writer {
  id: string;
  name: string;
  bio?: string;
  image?: string;
  _count: {
    articles: number;
  };
}

const WriterSection = () => {
  const [writers, setWriters] = useState<Writer[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchWriters = async () => {
      try {
        setLoading(true);
        const response = await fetch('/api/writers');
        
        if (!response.ok) {
          throw new Error('Failed to fetch writers');
        }
        
        const data = await response.json();
        setWriters(data);
      } catch (err) {
        setError('Error loading writers');
        console.error('Error fetching writers:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchWriters();
  }, []);

  if (loading) {
    return (
      <section className="py-12">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold mb-8">Our Writers</h2>
          <div className="flex justify-center items-center h-64">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
          </div>
        </div>
      </section>
    );
  }

  if (error) {
    return (
      <section className="py-12">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold mb-8">Our Writers</h2>
          <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">
            {error}
          </div>
        </div>
      </section>
    );
  }

  return (
    <section className="py-12">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold mb-8">Our Writers</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {writers.map((writer) => (
            <div key={writer.id} className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="p-4 text-center">
                <div className="relative h-32 w-32 mx-auto mb-4 rounded-full overflow-hidden">
                  <Image
                    src={writer.image || '/placeholder-writer.jpg'}
                    alt={writer.name}
                    fill
                    style={{ objectFit: 'cover' }}
                  />
                </div>
                <h3 className="text-xl font-semibold mb-2">{writer.name}</h3>
                <p className="text-gray-600 mb-2">{writer.bio || 'Writer at Eastern Insight'}</p>
                <p className="text-sm text-blue-600">{writer._count.articles} Articles</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default WriterSection;