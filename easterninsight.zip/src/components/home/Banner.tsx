'use client';

import { useEffect, useState } from 'react';
import Image from 'next/image';

interface Banner {
  id: string;
  title: string;
  subtitle?: string;
  description?: string;
  imageUrl: string;
  linkUrl?: string;
  linkText?: string;
  isActive: boolean;
}

const Banner = () => {
  const [banner, setBanner] = useState<Banner | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchBanner = async () => {
      try {
        setLoading(true);
        const response = await fetch('/api/banners?active=true');
        
        if (!response.ok) {
          throw new Error('Failed to fetch banner');
        }
        
        const data = await response.json();
        // Get the first active banner
        setBanner(data.length > 0 ? data[0] : null);
      } catch (err) {
        setError('Error loading banner');
        console.error('Error fetching banner:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchBanner();
  }, []);

  if (loading) {
    return (
      <section className="relative h-96 w-full overflow-hidden bg-gray-300 animate-pulse">
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
        </div>
      </section>
    );
  }

  if (error || !banner) {
    // Fallback banner if there's an error or no banner found
    return (
      <section className="relative h-96 w-full overflow-hidden bg-gray-800">
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-center text-white px-4">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">Eastern Insight</h1>
            <p className="text-xl md:text-2xl max-w-3xl">
              {error || "Delivering insightful news and analysis on politics, business, sports, and more."}
            </p>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section className="relative h-96 w-full overflow-hidden">
      <div className="absolute inset-0">
        <Image
          src={banner.imageUrl}
          alt={banner.title}
          fill
          priority
          style={{ objectFit: 'cover' }}
        />
      </div>
      <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center">
        <div className="text-center text-white px-4">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">{banner.title}</h1>
          {banner.subtitle && <h2 className="text-2xl md:text-3xl mb-2">{banner.subtitle}</h2>}
          {banner.description && <p className="text-xl md:text-2xl max-w-3xl mb-6">{banner.description}</p>}
          {banner.linkUrl && banner.linkText && (
            <a 
              href={banner.linkUrl} 
              className="inline-block bg-blue-600 text-white px-6 py-2 rounded-md hover:bg-blue-700 transition-colors"
            >
              {banner.linkText}
            </a>
          )}
        </div>
      </div>
    </section>
  );
};

export default Banner;