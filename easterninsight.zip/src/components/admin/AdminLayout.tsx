// components/admin/AdminLayout.tsx
'use client';
import { useState, useEffect } from 'react';
import { useRouter, usePathname } from 'next/navigation';

interface User {
  _id: string;
  name: string;
  email: string;
  role: string;
  image?: string;
}

interface AdminLayoutProps {
  children: React.ReactNode;
}

export default function AdminLayout({ children }: AdminLayoutProps) {
  const router = useRouter();
  const pathname = usePathname();
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [debugInfo, setDebugInfo] = useState<any>(null);

  // Only fetch user data if we're on an admin route
  useEffect(() => {
    // Don't run on login page
    if (pathname === '/login' || pathname === '/register') {
      setLoading(false);
      return;
    }

    const fetchUserData = async () => {
      try {
        const token = localStorage.getItem('token');
        
        if (!token) {
          console.log('❌ [DEBUG] No token found in localStorage');
          // Instead of redirecting immediately, set user to null and let the component render
          setUser(null);
          setLoading(false);
          return;
        }
        
        console.log('🔍 [DEBUG] Token from localStorage:', token.substring(0, 20) + '...');
        
        // First, validate the token
        const validateResponse = await fetch('/api/auth/validate-token', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ token }),
        });
        
        const validationData = await validateResponse.json();
        console.log('🔍 [DEBUG] Token validation result:', validationData);
        setDebugInfo(validationData);
        
        if (!validationData.valid) {
          console.log('❌ [DEBUG] Token validation failed:', validationData.error);
          localStorage.removeItem('token');
          localStorage.removeItem('user');
          setUser(null);
          setLoading(false);
          return;
        }
        
        // Then fetch user data
        console.log('✅ [DEBUG] Token is valid, fetching user data...');
        const response = await fetch('/api/auth/me', {
          headers: {
            'Authorization': `Bearer ${token}`
          }
        });
        
        if (!response.ok) {
          const errorData = await response.json();
          console.log('❌ [DEBUG] API error:', errorData);
          
          if (response.status === 401) {
            localStorage.removeItem('token');
            localStorage.removeItem('user');
            setUser(null);
          }
          setLoading(false);
          return;
        }
        
        const userData = await response.json();
        console.log('✅ [DEBUG] User data received:', userData);
        setUser(userData);
        setLoading(false);
      } catch (error) {
        console.error('❌ [DEBUG] Fetch error:', error);
        setUser(null);
        setLoading(false);
      }
    };

    fetchUserData();
  }, [pathname, router]);

  const handleLogout = async () => {
    try {
      await fetch('/api/auth/logout', {
        method: 'POST',
      });
      
      localStorage.removeItem('token');
      localStorage.removeItem('user');
      setUser(null);
      // Use window.location for a full redirect to login
      window.location.href = '/login';
    } catch (error) {
      console.error('Logout error:', error);
    }
  };

  // Show loading state
  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  // If we're on login page, just render children without the admin layout
  if (pathname === '/login' || pathname === '/register') {
    return <>{children}</>;
  }

  // If no user and not on login page, redirect to login
  if (!user) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center">
        <div className="text-center mb-6">
          <h2 className="text-2xl font-bold text-gray-900">Authentication Required</h2>
          <p className="mt-2 text-gray-600">Please log in to access this page.</p>
        </div>
        <button
          onClick={() => router.push('/login')}
          className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md"
        >
          Go to Login Page
        </button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Debug Panel - Remove in production */}
      <div className="bg-yellow-100 border-b border-yellow-300 p-4">
        <h3 className="font-bold text-yellow-800">Debug Information</h3>
        <details className="mt-2">
          <summary className="cursor-pointer text-yellow-700">View Debug Info</summary>
          <pre className="mt-2 p-2 bg-yellow-50 rounded text-xs overflow-auto">
            {JSON.stringify(debugInfo, null, 2)}
          </pre>
        </details>
      </div>
      
      {/* Rest of your layout */}
      <div className="flex">
        {/* Sidebar */}
        <div className="w-64 bg-white shadow-md">
          <div className="p-4 border-b">
            <h1 className="text-xl font-bold">Admin Panel</h1>
          </div>
          <nav className="p-4">
            <ul className="space-y-2">
              <li>
                <a 
                  href="/admin" 
                  className={`block px-4 py-2 rounded hover:bg-gray-100 ${pathname === '/admin' ? 'bg-gray-100' : ''}`}
                >
                  Dashboard
                </a>
              </li>
              <li>
                <a 
                  href="/admin/articles" 
                  className={`block px-4 py-2 rounded hover:bg-gray-100 ${pathname === '/admin/articles' ? 'bg-gray-100' : ''}`}
                >
                  Articles
                </a>
              </li>
              <li>
                <a 
                  href="/admin/categories" 
                  className={`block px-4 py-2 rounded hover:bg-gray-100 ${pathname === '/admin/categories' ? 'bg-gray-100' : ''}`}
                >
                  Categories
                </a>
              </li>
              <li>
                <a 
                  href="/admin/users" 
                  className={`block px-4 py-2 rounded hover:bg-gray-100 ${pathname === '/admin/users' ? 'bg-gray-100' : ''}`}
                >
                  Users
                </a>
              </li>
            </ul>
          </nav>
          <div className="p-4 border-t">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <div className="h-8 w-8 rounded-full bg-gray-300"></div>
              </div>
              <div className="ml-3">
                <p className="text-sm font-medium">{user?.name}</p>
                <p className="text-xs text-gray-500">{user?.role}</p>
              </div>
            </div>
            <button
              onClick={handleLogout}
              className="mt-3 w-full text-left px-4 py-2 text-sm text-red-600 hover:bg-red-50 rounded"
            >
              Logout
            </button>
          </div>
        </div>
        
        {/* Main content */}
        <div className="flex-1">
          {children}
        </div>
      </div>
    </div>
  );
}