import { NextRequest, NextResponse } from 'next/server';
import db from '../../../../utils/db';

// GET /api/banners/[id] - Get a specific banner
export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const banner = await db.getBannerById(params.id);
    
    if (!banner) {
      return NextResponse.json(
        { error: 'Banner not found' },
        { status: 404 }
      );
    }
    
    return NextResponse.json(banner);
  } catch (error) {
    console.error('Error fetching banner:', error);
    return NextResponse.json(
      { error: 'Failed to fetch banner' },
      { status: 500 }
    );
  }
}

// PUT /api/banners/[id] - Update a banner (admin only)
export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    // Get user from request (added by middleware)
    // @ts-ignore - user is added by middleware
    const user = request.user;
    
    if (!user || user.role !== 'ADMIN') {
      return NextResponse.json(
        { error: 'Unauthorized - Only admins can update banners' },
        { status: 403 }
      );
    }
    
    // Check if banner exists
    const banner = await db.getBannerById(params.id);
    if (!banner) {
      return NextResponse.json(
        { error: 'Banner not found' },
        { status: 404 }
      );
    }
    
    const { title, description, imageUrl, linkUrl, linkText, isActive, order } = await request.json();
    
    // Update banner
    const updatedBanner = await db.updateBanner(params.id, {
      title,
      description,
      imageUrl,
      linkUrl,
      linkText,
      isActive,
      order
    });
    
    return NextResponse.json(updatedBanner);
  } catch (error) {
    console.error('Error updating banner:', error);
    return NextResponse.json(
      { error: 'Failed to update banner' },
      { status: 500 }
    );
  }
}

// DELETE /api/banners/[id] - Delete a banner (admin only)
export async function DELETE(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    // Get user from request (added by middleware)
    // @ts-ignore - user is added by middleware
    const user = request.user;
    
    if (!user || user.role !== 'ADMIN') {
      return NextResponse.json(
        { error: 'Unauthorized - Only admins can delete banners' },
        { status: 403 }
      );
    }
    
    // Check if banner exists
    const banner = await db.getBannerById(params.id);
    if (!banner) {
      return NextResponse.json(
        { error: 'Banner not found' },
        { status: 404 }
      );
    }
    
    // Delete banner
    await db.deleteBanner(params.id);
    
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error deleting banner:', error);
    return NextResponse.json(
      { error: 'Failed to delete banner' },
      { status: 500 }
    );
  }
}