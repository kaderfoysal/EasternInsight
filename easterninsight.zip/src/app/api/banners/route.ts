import { NextRequest, NextResponse } from 'next/server';
import db from '../../../utils/db';

// GET /api/banners - Get all banners
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const active = searchParams.get('active');
    
    const banners = await db.getBanners(active === 'true');
    
    return NextResponse.json(banners);
  } catch (error) {
    console.error('Error fetching banners:', error);
    return NextResponse.json(
      { error: 'Failed to fetch banners' },
      { status: 500 }
    );
  }
}

// POST /api/banners - Create a new banner (admin only)
export async function POST(request: NextRequest) {
  try {
    // Get user from request (added by middleware)
    // @ts-ignore - user is added by middleware
    const user = request.user;
    
    if (!user || user.role !== 'ADMIN') {
      return NextResponse.json(
        { error: 'Unauthorized - Only admins can create banners' },
        { status: 403 }
      );
    }
    
    const { title, description, imageUrl, linkUrl, linkText, isActive, order } = await request.json();
    
    // Validate required fields
    if (!title || !imageUrl) {
      return NextResponse.json(
        { error: 'Title and image URL are required' },
        { status: 400 }
      );
    }
    
    // Create banner
    const banner = await db.createBanner({
      title,
      description: description || '',
      imageUrl,
      linkUrl: linkUrl || '',
      linkText: linkText || '',
      isActive: isActive || false,
      order: order || 0
    });
    
    return NextResponse.json(banner, { status: 201 });
  } catch (error) {
    console.error('Error creating banner:', error);
    return NextResponse.json(
      { error: 'Failed to create banner' },
      { status: 500 }
    );
  }
}