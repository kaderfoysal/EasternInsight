// app/api/auth/me/route.ts
import { NextRequest, NextResponse } from 'next/server';
import jwt from 'jsonwebtoken';
import db from '../../../../utils/db';

// Explicitly set runtime to Node.js
export const runtime = 'nodejs';

export async function GET(request: NextRequest) {
  try {
    // Get token from Authorization header
    const authHeader = request.headers.get('Authorization');
    console.log('🔍 [DEBUG] Authorization header:', authHeader);
    
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      console.log('❌ [DEBUG] No valid Authorization header found');
      return NextResponse.json(
        { error: 'Authorization token is required' },
        { status: 401 }
      );
    }
    
    const token = authHeader.substring(7); // Remove "Bearer " prefix
    console.log('🔍 [DEBUG] Token extracted:', token.substring(0, 20) + '...');
    
    // Verify token and get user info
    const jwtSecret = process.env.JWT_SECRET;
    console.log('🔍 [DEBUG] JWT_SECRET exists:', !!jwtSecret);
    console.log('🔍 [DEBUG] JWT_SECRET length:', jwtSecret?.length || 0);
    
    if (!jwtSecret) {
      console.error('❌ [DEBUG] JWT_SECRET is not defined in environment variables');
      return NextResponse.json(
        { error: 'JWT_SECRET is not defined' },
        { status: 500 }
      );
    }
    
    let payload;
    try {
      payload = jwt.verify(token, jwtSecret);
      console.log('✅ [DEBUG] Token verified successfully');
      console.log('🔍 [DEBUG] Token payload:', JSON.stringify(payload, null, 2));
    } catch (jwtError) {
      console.error('❌ [DEBUG] JWT verification error:', jwtError);
      console.error('❌ [DEBUG] Error name:', (jwtError as Error).name);
      console.error('❌ [DEBUG] Error message:', (jwtError as Error).message);
      
      return NextResponse.json(
        { 
          error: 'Invalid or expired token',
          details: (jwtError as Error).message 
        },
        { status: 401 }
      );
    }
    
    // Get the user from the database
    console.log('🔍 [DEBUG] Looking for user with ID:', payload.id);
    const user = await db.findUserById(payload.id);
    
    if (!user) {
      console.log('❌ [DEBUG] User not found in database');
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      );
    }
    
    console.log('✅ [DEBUG] User found:', user.name);
    
    // Return user data (excluding password)
    const { password, ...userWithoutPassword } = user;
    
    return NextResponse.json(userWithoutPassword);
  } catch (error) {
    console.error('❌ [DEBUG] Unexpected error:', error);
    
    return NextResponse.json(
      { error: 'Failed to get current user' },
      { status: 500 }
    );
  }
}