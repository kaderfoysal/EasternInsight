// app/api/articles/route.ts
import { NextRequest, NextResponse } from 'next/server';
import db from '../../../utils/db';

// Explicitly set runtime to Node.js
export const runtime = 'nodejs';

// GET /api/articles - Get all articles
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const category = searchParams.get('category');
    const limit = searchParams.get('limit') ? parseInt(searchParams.get('limit') as string) : undefined;
    const page = searchParams.get('page') ? parseInt(searchParams.get('page') as string) : 1;
    const skip = page && limit ? (page - 1) * limit : 0;
    
    console.log('🔍 [DEBUG] Fetching articles with params:', { category, limit, page, skip });
    
    // Build filter object
    const filter: any = {};
    if (category) {
      filter.categoryId = category;
    }
    
    // Get articles with pagination
    const articles = await db.getArticles(filter, limit, skip);
    
    // Get total count for pagination
    const total = await db.countArticles(filter);
    
    console.log('✅ [DEBUG] Articles fetched successfully:', articles.length);
    
    return NextResponse.json({
      articles,
      pagination: {
        total,
        page,
        limit,
        totalPages: limit ? Math.ceil(total / limit) : 1,
      },
    });
  } catch (error) {
    console.error('❌ [DEBUG] Error fetching articles:', error);
    return NextResponse.json(
      { error: 'Failed to fetch articles' },
      { status: 500 }
    );
  }
}

// POST /api/articles - Create a new article
export async function POST(request: NextRequest) {
  try {
    // Get token from Authorization header
    const authHeader = request.headers.get('Authorization');
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return NextResponse.json(
        { error: 'Authorization token is required' },
        { status: 401 }
      );
    }

    const token = authHeader.substring(7); // Remove "Bearer " prefix
    
    // Verify token and get user info
    const jwtSecret = process.env.JWT_SECRET;
    if (!jwtSecret) {
      return NextResponse.json(
        { error: 'JWT_SECRET is not defined' },
        { status: 500 }
      );
    }

    const payload = jwt.verify(token, jwtSecret) as any;
    const userId = payload.id;

    const { 
      title, 
      content, 
      summary, 
      categoryId, 
      featuredImage, 
      published,
      featured,
      latest,
      latestFeatured
    } = await request.json();
    
    console.log('🔍 [DEBUG] Creating article with data:', { title, categoryId, published });
    
    // Validate required fields
    if (!title || !content || !categoryId) {
      return NextResponse.json(
        { error: 'Title, content, and category are required' },
        { status: 400 }
      );
    }
    
    // Create article
    const article = await db.createArticle({
      title,
      content,
      summary: summary || '',
      categoryId,
      authorId: userId, // Use authenticated user's ID
      featuredImage: featuredImage || '',
      published: published || false,
      featured: featured || false,
      latest: latest || false,
      latestFeatured: latestFeatured || false,
      comments: [] // Initialize with empty comments array
    });
    
    console.log('✅ [DEBUG] Article created successfully');
    
    return NextResponse.json(article, { status: 201 });
  } catch (error) {
    console.error('❌ [DEBUG] Error creating article:', error);
    
    if (error instanceof jwt.JsonWebTokenError) {
      return NextResponse.json(
        { error: 'Invalid token' },
        { status: 401 }
      );
    }
    
    return NextResponse.json(
      { error: 'Failed to create article' },
      { status: 500 }
    );
  }
}